﻿#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSqlDatabase>     //数据库连接
#include <QSqlTableModel>   //数据表模型


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButtonConnect_clicked();

    void on_pushButtonGetTables_clicked();

    void on_comboBoxTablesList_currentIndexChanged(const QString &arg1);

    void on_pushButtonAddOneLine_clicked();

    void on_pushButtonCommit_clicked();

    void on_pushButtonDelCurOne_clicked();

    void on_pushButtonCancelEdit_clicked();

private:
    Ui::Widget *ui;
    //数据库
    QSqlDatabase m_db;
    //数据表模型
    QSqlTableModel *m_pTableModel;
};

#endif // WIDGET_H

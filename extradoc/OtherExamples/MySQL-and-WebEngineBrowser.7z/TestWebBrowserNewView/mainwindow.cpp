﻿#pragma execution_character_set("utf-8")
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QMessageBox>
#include <QUrl>
#include <QHBoxLayout>
#include <QWebEnginePage>
#include <QWebEngineHistory>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_pView = NULL;
    m_pURLEdit = NULL;

    //初始化
    InitMainUI();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::InitMainUI()
{
    QString strHome = "http://www.baidu.com/";  //主页
    //新建URL编辑器
    m_pURLEdit = new QLineEdit(this);
    m_pURLEdit->setText(strHome);
    //用户输入了新网址，加载它
    connect(m_pURLEdit, SIGNAL(returnPressed()), this, SLOT(onUrlEditChanged()));
    //放进工具栏
    ui->mainToolBar->insertWidget(ui->actionRefresh, m_pURLEdit);

    //退出菜单项关联
    connect(ui->actionQuit, SIGNAL(triggered()), qApp, SLOT(quit()));

    //新建视图
    CreateNewWebView(strHome);
}

void MainWindow::CreateNewWebView(const QString &strUrl)
{
    //删除旧的视图
    this->setCentralWidget(NULL);

    if(NULL != m_pView)
    {
        m_pView->stop();
        m_pView->deleteLater();//让该对象自动删除
        m_pView = NULL;
    }
    //标题栏显示为等待
    this->setWindowTitle("Waiting ......");
    /*********************************************/
    //创建新的视图
    //新建网页视图，并设为中央控件
    m_pView = new QWebEngineView();
    this->setCentralWidget(m_pView);
    //关联信号和槽，浏览四个工具按钮
    connect(ui->actionBackward, SIGNAL(triggered()), m_pView, SLOT(back()));
    connect(ui->actionForward, SIGNAL(triggered()), m_pView, SLOT(forward()));
    connect(ui->actionRefresh, SIGNAL(triggered()), m_pView, SLOT(reload()));
    connect(ui->actionStop, SIGNAL(triggered()), m_pView, SLOT(stop()));

    //显示网页标题和当前网址
    connect(m_pView, SIGNAL(titleChanged(QString)), this, SLOT(onTitleChanged(QString)));
    connect(m_pView, SIGNAL(urlChanged(QUrl)), this, SLOT(onUrlChanged(QUrl)));
    //鼠标指向链接时，显示链接到状态栏
    connect(m_pView->page(), SIGNAL(linkHovered(QString)), this, SLOT(onLinkHovered(QString)));

    //加载初始的网页
    m_pView->setUrl( QUrl::fromUserInput(strUrl) );
    m_pView->show();
}

//网页标题
void MainWindow::onTitleChanged(const QString &title)
{
    this->setWindowTitle(title);
}
//网页链接地址
//用户点击网页触发
//QWebEngineView有毛病，用户点击网页里的链接时，只触发urlChanged(QUrl)信号
//不自动加载新链接网页，需要手动加载
void MainWindow::onUrlChanged(const QUrl &url)
{
    //地址栏的旧网址
    QUrl old = QUrl( m_pURLEdit->text() );
    //链接有变化才更新，用户点击网页里的新链接会触发
    if(url != old)
    {
        m_pURLEdit->setText( url.toString() );
        //用户点击了新网页，但是没自动加载，手动刷新
        m_pView->load(url);//要放在if判断内部，否则容易无限刷新，死循环
    }

    qDebug()<<url;
}
//加载输入的网址
void MainWindow::onUrlEditChanged()
{
    QString strUrl = m_pURLEdit->text();
    QUrl url = QUrl::fromUserInput(strUrl);
    //用户输入的与当前网址不一样，加载新的
    if(url != m_pView->url())
    {
        //创建新视图加载网页
        CreateNewWebView(url.toString());
    }
    qDebug()<<tr("输入的网址：")<<strUrl;
}
//链接状态显示
void MainWindow::onLinkHovered(const QString &url)
{
    ui->statusBar->showMessage(url);
}



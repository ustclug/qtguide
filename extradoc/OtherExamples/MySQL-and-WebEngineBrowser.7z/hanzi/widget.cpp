﻿#pragma execution_character_set("utf-8")
#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //
    qDebug()<<"汉字呀";
    qDebug()<<tr("乱码吗");
    QMessageBox::information(this, "hello", tr("乱码了"));
}

Widget::~Widget()
{
    delete ui;
}

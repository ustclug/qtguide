#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QUrl>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void onUrlEdited();
    void onUrlChanged(const QUrl &url);
    void onLinkClicked(const QUrl &url);
    void onLinkHovered(const QString &link, const QString &title, const QString &textContent);

private:
    Ui::MainWindow *ui;
    //地址栏
    QLineEdit *m_pUrlEdit;
    //初始化一下界面
    void InitAllUI();
};

#endif // MAINWINDOW_H

﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWebEngineView>
#include <QLineEdit>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

signals:

public slots:
    void onUrlChanged(const QUrl &url);
    void onTitleChanged(const QString &title);
    void onUrlEditChanged();
    void onLinkHovered(const QString &url);

private:
    Ui::MainWindow *ui;
    //Init
    void InitMainUI();
    QWebEngineView *m_pView;
    QLineEdit *m_pURLEdit;

    //new view
    void CreateNewWebView(const QString &strUrl);

};

#endif // MAINWINDOW_H

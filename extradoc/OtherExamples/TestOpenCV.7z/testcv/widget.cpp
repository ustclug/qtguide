#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <opencv2/opencv.hpp>
#include <QDebug>
#include <QFileDialog>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    QString strQFileName = QFileDialog::getOpenFileName(
                this,
                tr("打开图片"),
                tr("."),
                tr("Image files(*.jpg *.png *.jpeg *.jp2 *.bmp);;All files(*)"));
    if(strQFileName.isEmpty())
    {
        return;
    }

    QString strWindowsTitle = tr("OpenCV第一个程序(http://blog.csdn.net/MoreWindows)");

    //从文件中读取图像
    IplImage *pImage = cvLoadImage(strQFileName.toLocal8Bit().data(), CV_LOAD_IMAGE_UNCHANGED);

    //创建窗口
    cvNamedWindow(strWindowsTitle.toLocal8Bit().data(), CV_WINDOW_AUTOSIZE);

    //在指定窗口中显示图像
    cvShowImage(strWindowsTitle.toLocal8Bit().data(), pImage);

    //等待按键事件
    cvWaitKey();

    cvDestroyWindow(strWindowsTitle.toLocal8Bit().data());
    cvReleaseImage(&pImage);
}

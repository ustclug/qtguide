﻿#pragma execution_character_set("utf-8")
#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
//使用数据库时，pro文件的 QT +=  后面补充一个 sql
#include <QSqlError>    //报错用的
#include <QSqlRecord>   //数据库记录行

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    //初始化
    m_pTableModel = NULL;

    qsrand( time_t() );   //初始随机种子
}

Widget::~Widget()
{
    //
    ui->tableView->setModel(NULL);
    delete m_pTableModel;   m_pTableModel = NULL;
    //
    delete ui;
}

void Widget::on_pushButtonConnect_clicked()
{
    if( m_db.isOpen() )
    {
        qDebug()<<tr("已经连接到qtguide数据库.");
        return;
    }
    //新建连接
    m_db = QSqlDatabase::addDatabase("QMYSQL");
    m_db.setHostName("127.0.0.1");    //目前是本地MySQL数据库，也可以连接网络上的
    m_db.setDatabaseName("qtguide");  //这是自己在MySQL里新建的数据库、用户名和密码
    m_db.setUserName("qtguide");
    m_db.setPassword("qtguide");
    bool ok = m_db.open();
    if( ! ok )
    {
        QMessageBox::critical(this, tr("MySQL数据库连接"),
                                 tr("连接错误：%1").arg(m_db.lastError().text()));
        return;
    }
    else
    {
        QMessageBox::information(this, tr("MySQL数据库连接"),
                                 tr("连接成功，使用数据库qtguide。"));
    }

}

void Widget::on_pushButtonGetTables_clicked()
{
    if(! m_db.isOpen())
    {
        QMessageBox::warning(this, tr("枚举数据库表格"),
                             tr("数据库未连接，无法枚举数据库表哥名。"));
        return;
    }
    //清空旧的组合框列表
    ui->comboBoxTablesList->clear();
    //开始枚举
    QStringList listTables = m_db.tables();
    //添加
    ui->comboBoxTablesList->addItems(listTables);
}

void Widget::on_comboBoxTablesList_currentIndexChanged(const QString &arg1)
{
    if(arg1.isEmpty())
    {
        return; //不处理，没有表格名
    }
    //清除旧的
    delete m_pTableModel;   m_pTableModel = NULL;
    //加载数据表格
    m_pTableModel = new QSqlTableModel(this, m_db);
    m_pTableModel->setTable(arg1);  //参数里的是表格名字
    m_pTableModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    m_pTableModel->select();    //加载数据，默认缓冲256行

    //穷举所有的行都加载，如果不穷举加载，那么默认只加载256行
    //小表格可以穷举，太多行就不适合穷举加载
    while(m_pTableModel->canFetchMore())
    {
        m_pTableModel->fetchMore();
    }

    //显示
    ui->tableView->setModel(m_pTableModel);
    qDebug()<<tr("已经加载表格：")<<arg1;
}

//表格直接双击编辑，不需要编辑按钮
//用一个增加按钮和删除按钮就差不多了
void Widget::on_pushButtonAddOneLine_clicked()
{
    if(NULL == m_pTableModel)
    {
        return; //没表格，不处理
    }
    //获取记录模板，有各个字段名
    QSqlRecord reNew = m_pTableModel->record(); //获取该表格的记录模板
    //record()函数如果不带参数就是获取记录行模板
    //如果带参数就是第几行的记录，比如 record(0) 就是头一行

    reNew.setValue(0, qrand()); //该行记录的第0列，随便设置一个值
    //如果设置其他lie列就用对应的列号

    m_pTableModel->insertRecord(-1, reNew); //插入记录到末尾

}

//删除当前行
void Widget::on_pushButtonDelCurOne_clicked()
{
    if(NULL == m_pTableModel)
    {
        return; //没表格，不处理
    }
    //只删除一行
    QModelIndex curIndex = ui->tableView->currentIndex();
    //判断该索引是否被选中了
    if( ! (ui->tableView->selectionModel()->isSelected( curIndex )) )
    {
        //没选中，不删除
        qDebug()<<tr("未选中，不删除：")<<curIndex;
        return;
    }
    //删除选中的行
    int nCurLine = curIndex.row();
    if(nCurLine < 0)
    {
        return; //行号不对，没东西可删除
    }
    else
    {
        m_pTableModel->removeRow(nCurLine);
    }

}

//取消编辑
void Widget::on_pushButtonCancelEdit_clicked()
{
    if(NULL == m_pTableModel)
    {
        return; //没表格，不处理
    }
    m_pTableModel->revertAll(); //撤销之前的编辑操作
}

//提交
void Widget::on_pushButtonCommit_clicked()
{
    if(NULL == m_pTableModel)
    {
        return; //没表格，不处理
    }
    bool ok = m_pTableModel->submitAll();
    if( ok )
    {
        QMessageBox::information(this, tr("提交"),
                                 tr("提交更改到数据库成功。"));
    }
    else
    {
        QMessageBox::warning(this, tr("提交"),
                             tr("提交更改失败：%1\r\n请将每列的数据填完整，并且主键列的值不能相同。").arg(m_db.lastError().text()));
        return;
    }
}
